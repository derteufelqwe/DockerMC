create index NAME_INDEX
    on PLAYERS (NAME);

